﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace projeto3
{
    public partial class Form1 : Form
    {
        banco bd = new banco();
        string sql;
        MySqlCommand cmd;
        string Id;

        public Form1()
        {
            InitializeComponent();
            busca();
            FillFuncionario();
            FillCliente();
            FillServico();
        }



        private void busca()
        {
            bd.abrirConn();
            sql = "select * from agendamento";
            cmd = new MySqlCommand(sql, bd.conecta);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.SelectCommand = cmd;
            DataTable dataTable = new DataTable();
            da.Fill(dataTable);
            dataGridView1.DataSource = dataTable;
        }

        private void FillCliente()
        {
            bd.abrirConn();
            sql = "select nome from cliente";
            cmd = new MySqlCommand(sql, bd.conecta);

            MySqlDataAdapter da = new MySqlDataAdapter();
            da.SelectCommand = cmd;
            DataTable dt = new DataTable();
            da.Fill(dt);
            {
                cbCliente.DataSource = dt;
                cbCliente.DisplayMember = "nome";
            }

        }


        private void FillFuncionario()
        {
            bd.abrirConn();
            sql = "select nome from funcionario";
            cmd = new MySqlCommand(sql, bd.conecta);

            MySqlDataAdapter da = new MySqlDataAdapter();
            da.SelectCommand = cmd;
            DataTable dt = new DataTable();
            da.Fill(dt);
            {
                cbFunc.DataSource = dt;
                cbFunc.DisplayMember = "nome";
            }

        }
        private void FillServico()
        {
            bd.abrirConn();
            sql = "select nome from servico";
            cmd = new MySqlCommand(sql, bd.conecta);

            MySqlDataAdapter da = new MySqlDataAdapter();
            da.SelectCommand = cmd;
            DataTable dt = new DataTable();
            da.Fill(dt);
            {
                cbServico.DataSource = dt;
                cbServico.DisplayMember = "nome";
            }
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            bd.abrirConn();
            sql = "SELECT Cliente.NOME AS Cliente, Servico.NOME AS Servico, Agendamento.DATA_AGENDAMENTO, Agendamento.HORA_AGENDAMENTO, Funcionario.NOME AS Funcionario " +
                  "FROM agendamento " +
                  "INNER JOIN cliente ON Agendamento.FK_CLIENTE_ID = cliente.id " +
                  "INNER JOIN servico ON Agendamento.FK_SERVICO_ID = servico.id " +
                  "INNER JOIN funcionario ON Agendamento.FUNCIONARIO_ID = funcionario.id " +
                  "WHERE Agendamento.DATA_AGENDAMENTO = @DataAgenda";

            cmd = new MySqlCommand(sql, bd.conecta);
            cmd.Parameters.AddWithValue("@DataAgenda", dtBusca.Value);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.SelectCommand = cmd;
            DataTable dataTable = new DataTable();
            da.Fill(dataTable);
            dataGridView1.DataSource = dataTable;
        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            

        }

       

    

        private void button2_Click(object sender, EventArgs e)
        {
            bd.abrirConn();
            sql = "INSERT INTO `agendamento`(`FUNCIONARIO_ID`, `FK_CLIENTE_ID`, `FK_SERVICO_ID`, `DATA_AGENDAMENTO`,`HORA_AGENDAMENTO`) VALUES (@DataAgenda, @Func,@Cliente,@Serv,@HoraAgenda)";
            cmd = new MySqlCommand(sql, bd.conecta);
            cmd.Parameters.AddWithValue("@Func", cbFunc.Text);
            cmd.Parameters.AddWithValue("@Cliente", cbCliente.Text);
            cmd.Parameters.AddWithValue("@Serv", cbServico.Text);
            cmd.Parameters.AddWithValue("@DataAgenda", dtAgendamento.Text);
            cmd.Parameters.AddWithValue("@HoraAgenda", dtHora.Text);
        

            cmd.ExecuteNonQuery();
        }

        
        

        private void cbFunc_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            



        }

        private void cbFunc_Click(object sender, EventArgs e)
        {
            
        }

        private void cbServico_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Tem certeza?", "Excluindo dados!", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes)
            {
                bd.abrirConn();
                sql = "Delete from usuario where id=@id";
                cmd = new MySqlCommand(sql, bd.conecta);
                cmd.Parameters.AddWithValue("@id", TbId.Text);
                cmd.ExecuteNonQuery();
                busca();
                MessageBox.Show("Dados deletados!");
            }
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            sql = "update usuario set nome=@nome,cpf=@cpf where id=@cod";
            cmd = new MySqlCommand(sql, bd.conecta);
            cmd.Parameters.AddWithValue("@Func", cbFunc.Text);
            cmd.Parameters.AddWithValue("@Cliente", cbCliente.Text);
            cmd.Parameters.AddWithValue("@Serv", cbServico.Text);
            cmd.Parameters.AddWithValue("@DataAgenda", dtAgendamento.Text);
            cmd.Parameters.AddWithValue("@HoraAgenda", dtHora.Text);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Ok");
        }

        private void dtBusca_ValueChanged(object sender, EventArgs e)
        {
            
        }

        
            
        }
    }
    
    

